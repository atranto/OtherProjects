The Java classes are under 'src'.
The data file is under 'data'.

The Java program was created in IntelliJ IDEA 2018.1.4 (64-bit version) instead of DrJava. Hence, the folder structure created by the program is reserved here.